/* tslint:disable */
/* eslint-disable */

/**
 * A serialisable binary relation (adjacency matrix) exposed to JavaScript.
 *
 * Construct via [`transitive_closure`], [`transitive_reduction`], or
 * [`get_order_of`].
 */
export class BinaryRelationJs {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Return all edges as a flat `[src0, tgt0, src1, tgt1, …]` array.
     */
    edges_flat(): Uint32Array;
    /**
     * Nodes with no outgoing edges.
     */
    end_nodes(): Uint32Array;
    /**
     * Test whether edge i→j exists.
     */
    is_edge(i: number, j: number): boolean;
    is_irreflexive(): boolean;
    is_strict_partial_order(): boolean;
    is_transitive(): boolean;
    /**
     * Number of nodes.
     */
    n(): number;
    /**
     * Nodes with no incoming edges.
     */
    start_nodes(): Uint32Array;
}

/**
 * Flat arena holding the entire POWL model tree.
 *
 * Construct with [`parse_powl`].  The root node is at index `model.root()`.
 */
export class PowlModel {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    is_empty(): boolean;
    /**
     * Total number of nodes in the arena.
     */
    len(): number;
    /**
     * Index of the root node.
     */
    root(): number;
}

/**
 * Compute A* alignments for every trace in an event log against a Petri net.
 *
 * Returns JSON with `total_cost`, `avg_cost`, `trace_alignments` (per-trace breakdown).
 *
 * Mirrors `pm4py.align_log()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function align_log(petri_net_json: string, log_json: string): string;

/**
 * Compute A* alignment for a single trace against a Petri net.
 *
 * Returns JSON with `cost`, `is_fit`, `moves` (each with `type`, `label`, `cost`).
 * Move types: "sync" (model+log match), "log" (log only), "model" (model only).
 *
 * Mirrors `pm4py.align_trace()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function align_trace(petri_net_json: string, trace_json: string): string;

/**
 * Check whether a Petri net is sound (deadlock-free, bounded, liveness).
 *
 * Returns JSON: `{"sound":true,"deadlock_free":true,"bounded":true,"liveness":true}`
 *
 * Mirrors `pm4py.check_soundness()`.
 */
export function check_soundness(petri_net_json: string): string;

/**
 * Check temporal conformance between an event log and a temporal profile.
 *
 * Returns JSON with fitness, deviations count, and detailed deviation list.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `profile_json` - Temporal profile JSON (from discover_temporal_profile)
 * * `zeta` - Number of standard deviations for threshold (typically 2.0)
 */
export function check_temporal_conformance(log_json: string, profile_json: string, zeta: number): string;

/**
 * Compute the behavioural footprints of a POWL model.
 *
 * Returns JSON with `start_activities`, `end_activities`, `activities`,
 * `skippable`, `sequence` (directly-follows pairs), `parallel` (concurrent pairs),
 * `activities_always_happening`, and `min_trace_length`.
 *
 * Mirrors the footprint analysis from `pm4py.discover_footprints()`.
 */
export function compute_footprints(model: PowlModel): string;

/**
 * Compute footprints-based conformance between an event log and a POWL model.
 *
 * Compares the log's directly-follows graph against the model's footprints to
 * compute fitness, precision, recall, and f1-score.
 *
 * Returns JSON: `{"fitness":0.95,"precision":0.85,"recall":0.90,"f1":0.87}`
 */
export function conformance_footprints(log_json: string, model_str: string): string;

/**
 * Count the number of reducible elements in a Petri net.
 *
 * Returns the count of elements that could be reduced by `reduce_petri_net()`.
 *
 * Mirrors `pm4py.count_reducible_elements()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function count_reducible_elements(petri_net_json: string): number;

/**
 * WASM export: DFG to DOT.
 */
export function dfg_to_dot_wasm(dfg_json: string): string;

/**
 * WASM export: DFG to JSON.
 */
export function dfg_to_json_wasm(dfg_json: string): string;

/**
 * Compute the structural and behavioural diff between two POWL model strings.
 *
 * Returns a JSON object describing added/removed activities, ordering changes,
 * structural operator changes, and an overall severity level.
 *
 * # Errors
 * Throws if either string fails to parse.
 */
export function diff_models(model_a: string, model_b: string): string;

/**
 * Detect batch processing patterns in an event log.
 *
 * Returns JSON with `batches` array, each containing `type` (sequential, concurrent,
 * parallel, concurrent_parallel), `activity`, `instances` with start/end timestamps.
 *
 * Mirrors `pm4py.discover_batches()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_batches(log_json: string): string;

/**
 * Discover a BPMN model directly from an event log using the inductive miner.
 *
 * Returns a complete BPMN 2.0 XML document. Combines inductive miner discovery
 * with BPMN conversion in a single call -- no intermediate steps required.
 *
 * Mirrors `pm4py.discover_bpmn_inductive()`.
 *
 * # Errors
 * Throws if the event log JSON cannot be parsed.
 */
export function discover_bpmn_inductive(log_json: string): string;

/**
 * Discover causal relations from a directly-follows graph (alpha variant).
 *
 * Causal relations identify which activities have a one-way dependency:
 * - A → B is causal if A always precedes B (B never precedes A)
 *
 * Returns JSON with `relations` map: (from, to) → 1 (binary causal indicator).
 *
 * Mirrors `pm4py.discover_causal()` with variant="alpha".
 *
 * # Arguments
 * * `dfg_json` - DFG JSON (from `discover_dfg`)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_causal_alpha(dfg_json: string): string;

/**
 * Discover causal relations from a directly-follows graph (heuristic variant).
 *
 * The heuristic variant uses a threshold-based approach where:
 * - Relation (A, B) is causal if its frequency is significantly higher than (B, A)
 *
 * Returns JSON with `relations` map: (from, to) → strength (0-1000).
 *
 * Mirrors `pm4py.discover_causal()` with variant="heuristic".
 *
 * # Arguments
 * * `dfg_json` - DFG JSON (from `discover_dfg`)
 * * `threshold` - Minimum ratio for causality (default: 0.8)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_causal_heuristic(dfg_json: string, threshold: number): string;

/**
 * Discover a process model using correlation mining (case-less / timestamp-based).
 *
 * Unlike other discovery algorithms, correlation mining works without case IDs
 * by detecting temporal gaps between activity occurrences.
 *
 * Returns JSON with `start_activity`, `end_activity`, `trace_count`, `edges`.
 *
 * Mirrors `pm4py.discover_correlation()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `correlation_threshold` - Gap threshold in seconds (typically 5.0-3600.0)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_correlation(log_json: string, correlation_threshold: number): string;

/**
 * Discover a DECLARE model from an event log.
 *
 * Returns JSON with constraint templates (response, precedence, succession, etc.)
 * and their support/confidence metrics.
 *
 * Mirrors `pm4py.discover_declare()`.
 */
export function discover_declare(log_json: string): string;

/**
 * Discover a Directly-Follows Graph from an event log.
 *
 * Returns JSON with `edges`, `start_activities`, `end_activities`, `activities`.
 *
 * Mirrors `pm4py.discover_dfg()`.
 */
export function discover_dfg(log_json: string): string;

/**
 * Discover a typed DFG (structured format) from an event log.
 *
 * Returns JSON with `graph` (from, to, frequency triples), `start_activities`,
 * `end_activities`, and `activities` (activity, frequency pairs).
 *
 * Mirrors `pm4py.discover_dfg_typed()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_dfg_typed(log_json: string): string;

/**
 * Discover an eventually-follows graph (all activity pairs in any trace).
 *
 * Returns JSON array of edges: `[{"source":"A","target":"C","count":2}, ...]`
 *
 * Mirrors `pm4py.discover_eventually_follows_graph()`.
 */
export function discover_eventually_follows_graph(log_json: string): string;

/**
 * Discover footprints from an event log.
 *
 * Computes footprints from the log's directly-follows graph.
 * Returns the same structure as `discover_footprints_from_model`.
 *
 * Mirrors `pm4py.discover_footprints()` for event logs.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_footprints_from_log(log_json: string): string;

/**
 * Discover footprints from a POWL model.
 *
 * Footprints summarize the behavioral properties of a process model:
 * - Start/end activities
 * - Sequence (directly-follows) and parallel (concurrent) pairs
 * - Minimum trace length
 * - Whether activities are skippable
 *
 * Mirrors `pm4py.discover_footprints()` for POWL models.
 *
 * # Errors
 * Throws if POWL string cannot be parsed.
 */
export function discover_footprints_from_model(powl_string: string): string;

/**
 * Discover a Heuristics Net from an event log.
 *
 * Returns JSON with activities, dependency measures, and start/end activities.
 *
 * Mirrors `pm4py.discover_heuristics_miner()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `dependency_threshold` - Minimum dependency score (0.0 to 1.0, typically 0.5-0.9)
 */
export function discover_heuristics_miner(log_json: string, dependency_threshold: number): string;

/**
 * Discover a Heuristics Net from an event log.
 *
 * Returns JSON with activities, dependencies (with dependency scores and frequencies),
 * and start/end activities. Useful for visualization of causal relations.
 *
 * Mirrors `pm4py.discover_heuristics_net()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `dependency_threshold` - Minimum dependency score for an edge (0.0 to 1.0)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_heuristics_net(log_json: string, dependency_threshold: number): string;

/**
 * Discover footprints directly from an event log's directly-follows graph.
 *
 * Returns JSON with `start_activities`, `end_activities`, `activities`,
 * `sequence` (directly-follows pairs), and `parallel` (bidirectional pairs).
 *
 * Mirrors `pm4py.discover_footprints()` applied to a log.
 */
export function discover_log_footprints(log_json: string): string;

/**
 * Discover a Log Skeleton from an event log.
 *
 * Returns JSON with six constraint types: equivalence, always_after, always_before,
 * never_together, directly_follows, and activ_freq.
 *
 * Mirrors `pm4py.discover_log_skeleton()`.
 */
export function discover_log_skeleton(log_json: string): string;

/**
 * Discover Event-Type / Object-Type graph from an OCEL.
 *
 * Input: OCEL JSON string.
 * Output: JSON with activities, object_types, edges, and edge_frequencies.
 *
 * Mirrors `pm4py.discover_ocel_etot()`.
 */
export function discover_ocel_etot(ocel_json: string): string;

/**
 * Discover a performance DFG with duration annotations on edges.
 *
 * Returns JSON with edges containing `avg_duration_ms`, `min_duration_ms`, `max_duration_ms`.
 *
 * Mirrors `pm4py.discover_performance_dfg()`.
 */
export function discover_performance_dfg(log_json: string): string;

/**
 * Discover performance spectrum for a specific activity.
 *
 * Returns JSON with `activity`, `overall_stats`, `instance_data` for visualization.
 * Useful for D3.js or similar charting libraries.
 *
 * Mirrors `pm4py.discover_performance_spectrum()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_performance_spectrum(log_json: string, activity: string): string;

/**
 * Discover a Petri net from an event log using the alpha miner.
 *
 * Returns the same JSON format as other discovery functions.
 *
 * Mirrors `pm4py.discover_petri_net_alpha()`.
 */
export function discover_petri_net_alpha(log_json: string): string;

/**
 * Discover a Petri net using the Alpha+ miner algorithm (extends Alpha with loop handling).
 *
 * Input: Event log JSON (same format as other discovery functions).
 * Output: PetriNetResult JSON with places, transitions, arcs, and markings.
 *
 * Returns the same JSON format as other discovery functions.
 *
 * Mirrors `pm4py.discover_petri_net_alpha_plus()`.
 */
export function discover_petri_net_alpha_plus(log_json: string): string;

/**
 * Discover a Petri net using the genetic miner (evolutionary algorithm).
 *
 * Returns the same JSON format as other discovery functions: `{net, initial_marking, final_marking}`.
 * Optionally accepts a JSON config object with `population_size`, `generations`,
 * `mutation_rate`, `crossover_rate`.
 *
 * Mirrors `pm4py.discover_petri_net_genetic()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_petri_net_genetic(log_json: string, config_json: string): string;

/**
 * Discover a Petri net from an event log using the heuristics miner.
 *
 * The heuristics miner is more lenient than the alpha miner for handling
 * noise and incomplete data. Uses dependency measures to filter causal relations.
 *
 * Returns the same JSON format as other discovery functions: `{net, initial_marking, final_marking}`.
 *
 * Mirrors `pm4py.discover_petri_net_heuristics()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `dependency_threshold` - Minimum dependency score for an edge (0.0 to 1.0, typically 0.8-0.99)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_petri_net_heuristics(log_json: string, dependency_threshold: number): string;

/**
 * Discover a Petri net using ILP miner (STUB - NOT IMPLEMENTED).
 *
 * The ILP (Integer Linear Programming) miner requires an LP solver
 * which is not available in pure WASM. This function returns an error.
 *
 * Consider using `discover_petri_net_inductive()` or `discover_petri_net_heuristics()` instead.
 *
 * Mirrors `pm4py.discover_petri_net_ilp()`.
 *
 * # Errors
 * Always throws an error explaining ILP miner is not available in WASM.
 */
export function discover_petri_net_ilp(_log_json: string, _alpha: number): string;

/**
 * Discover a Petri net from an event log using the inductive miner.
 *
 * Returns the same JSON as `powl_to_petri_net`: `{net, initial_marking, final_marking}`.
 *
 * Mirrors `pm4py.discover_petri_net_inductive()`.
 */
export function discover_petri_net_inductive(log_json: string): string;

/**
 * Discover a prefix tree (trie) from an event log.
 *
 * A prefix tree represents all unique prefixes of activity sequences in the log.
 * Each node in the tree represents an activity, and paths from root represent trace prefixes.
 * Nodes that represent the end of a trace are marked as `is_final = true`.
 *
 * Returns JSON with the trie structure: nodes array with label, parent, children, is_final, depth.
 *
 * Mirrors `pm4py.discover_prefix_tree()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `max_path_length` - Optional maximum trace length (traces are truncated)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_prefix_tree(log_json: string, max_path_length?: number | null): string;

/**
 * Discover a process tree using the inductive miner.
 *
 * Returns a JSON representation of the process tree with `label`, `operator`,
 * and `children` fields. Leaf nodes have `label` set; internal nodes have
 * `operator` set to one of: `"->"`, `"X"`, `"+"`, `"*"`.
 *
 * Mirrors `pm4py.discover_process_tree_inductive()`.
 */
export function discover_process_tree_inductive(log_json: string): string;

/**
 * Discover a temporal profile from an event log.
 *
 * Returns JSON with directly-follows pairs and their mean/stdev duration in ms.
 *
 * Mirrors `pm4py.discover_temporal_profile()`.
 */
export function discover_temporal_profile(log_json: string): string;

/**
 * Discover a transition system from an event log.
 *
 * A transition system is a state machine that captures all observed behavior:
 * - Each state represents a "view" of the trace (window of recent activities)
 * - Transitions represent activity executions that move between states
 *
 * Returns JSON with `states` (id, name) and `transitions` (from_state, to_state, activity, count).
 *
 * Mirrors `pm4py.discover_transition_system()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `window` - Size of the lookback window (default: 2)
 * * `direction` - "forward" (default) or "backward" direction
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function discover_transition_system(log_json: string, window: number, direction: string): string;

/**
 * Filter log to keep only traces between two activities.
 *
 * Keeps traces that contain both activities and where `act1` appears before `act2`.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_between()`.
 */
export function filter_between(log_json: string, act1: string, act2: string): string;

/**
 * Filter log to keep only traces within a case size range.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_case_size()`.
 */
export function filter_case_size(log_json: string, min_size: number, max_size: number): string;

/**
 * Filter log to keep only traces containing a specific activity relation.
 *
 * Keeps traces where activity `a` is directly followed by activity `b`.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_directly_follows_relation()`.
 */
export function filter_directly_follows_relation(log_json: string, a: string, b: string): string;

/**
 * Filter log to keep only traces ending with specified activities.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_end_activities()`.
 */
export function filter_end_activities(log_json: string, activities_json: string): string;

/**
 * Filter log to keep only traces starting with a specific prefix.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_prefixes()`.
 */
export function filter_prefixes(log_json: string, prefix_json: string): string;

/**
 * Filter log to keep only traces starting with specified activities.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_start_activities()`.
 */
export function filter_start_activities(log_json: string, activities_json: string): string;

/**
 * Filter log to keep only traces ending with a specific suffix.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_suffixes()`.
 */
export function filter_suffixes(log_json: string, suffix_json: string): string;

/**
 * Filter log to keep only events within a time range.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_time_range()`.
 */
export function filter_time_range(log_json: string, start_ms: bigint, end_ms: bigint): string;

/**
 * Trim traces to remove events before the first start activity and after the last end activity.
 *
 * Mirrors `pm4py.filter_trim()`.
 */
export function filter_trim(log_json: string, start_activity: string, end_activity: string): string;

/**
 * Filter log to keep only variants covering at least a percentage of traces.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_variants_by_coverage_percentage()`.
 */
export function filter_variants_coverage(log_json: string, min_coverage: number): string;

/**
 * Filter log to keep only the top K most frequent variants.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_variants_top_k()`.
 */
export function filter_variants_top_k(log_json: string, k: number): string;

/**
 * Compute footprints-based conformance diagnostics.
 *
 * Compares the log's directly-follows graph against a model's footprints
 * to compute fitness, precision, recall, and f1-score.
 *
 * Returns JSON: `{"fitness": 0.95, "precision": 0.85, "recall": 0.95, "f1": 0.90}`
 *
 * Mirrors `pm4py.conformance_diagnostics_footprints()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function footprints_diagnostics(log_json: string, model_fp_json: string): string;

/**
 * Compute footprints-based fitness.
 *
 * Fraction of the log's directly-follows pairs that are allowed by the model.
 * Returns a value in [0.0, 1.0] where 1.0 is perfect fitness.
 *
 * Mirrors `pm4py.fitness_footprints()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function footprints_fitness(log_json: string, model_fp_json: string): number;

/**
 * Compute footprints-based precision.
 *
 * Fraction of the model's directly-follows pairs that are observed in the log.
 * Returns a value in [0.0, 1.0] where 1.0 is perfect precision.
 *
 * Mirrors `pm4py.precision_footprints()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function footprints_precision(log_json: string, model_fp_json: string): number;

/**
 * Import a PNML 2.0 XML string into a PetriNetResult JSON.
 *
 * Mirrors `pm4py.read_pnml()`.
 *
 * # Errors
 * Throws if the PNML XML cannot be parsed.
 */
export function from_pnml(xml: string): string;

/**
 * Parse a PNML XML string (JSON-free) for WASM consumers.
 */
export function from_pnml_string(xml: string): string;

/**
 * WASM export: PTML to ProcessTree JSON.
 */
export function from_ptml_string(xml: string): string;

/**
 * Compute generalization quality metric for a Petri net against an event log.
 *
 * Returns JSON with `generalization` score in [0.0, 1.0].
 * Higher scores indicate the model generalizes well (not overfitting).
 *
 * Mirrors `pm4py.generalization()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function generalization(petri_net_json: string, log_json: string): string;

/**
 * Generate executable code from a POWL model string.
 *
 * Converts POWL to n8n JSON, Temporal Go, Camunda BPMN, or YAWL v6 XML.
 *
 * # Errors
 * Throws if the POWL string cannot be parsed or if the target is unknown.
 */
export function generate_code_from_powl(model_str: string, target: string): string;

/**
 * Get all case durations as a flat JSON array of milliseconds.
 *
 * Returns JSON: `[300000, 600000, 1800000, ...]`
 *
 * Mirrors `pm4py.get_all_case_durations()`.
 */
export function get_all_case_durations(log_json: string): string;

/**
 * Get all distinct values for a given event attribute with frequencies.
 *
 * Returns JSON: `[{"attribute":"concept:name","value":"A","count":3}, ...]`
 *
 * Mirrors `pm4py.get_attribute_values()`.
 */
export function get_attribute_values(log_json: string, attribute_key: string): string;

/**
 * Get the average case arrival rate (cases per hour).
 *
 * Mirrors `pm4py.get_case_arrival_average()`.
 */
export function get_case_arrival_average(log_json: string): number;

/**
 * Get case attributes with their statistics.
 *
 * Returns JSON: `[{"name":"case_id","count":3,"unique_values":3}, ...]`
 *
 * Mirrors `pm4py.get_case_attributes()`.
 */
export function get_case_attributes(log_json: string): string;

/**
 * Get case durations as JSON.
 *
 * Returns JSON: `[{"case_id":"1","duration_ms":300000}, ...]`
 *
 * Mirrors `pm4py.get_case_durations()`.
 */
export function get_case_durations(log_json: string): string;

/**
 * Get case overlap (fraction of shared prefixes between traces, 0.0–1.0).
 *
 * Mirrors `pm4py.get_case_overlap()`.
 */
export function get_case_overlap(log_json: string): number;

/**
 * Return the child arena indices of an SPO or OperatorPOWL node as a flat
 * `u32` array.  Returns an empty array for leaf nodes.
 */
export function get_children(model: PowlModel, arena_idx: number): Uint32Array;

/**
 * Get few-shot demos for a specific domain.
 *
 * Returns a JSON array of few-shot examples for LLM-guided POWL generation.
 * Supported domains: "loan_approval", "finance", "software_release", "it",
 * "devops", "ecommerce", "retail", "manufacturing", "production",
 * "healthcare", "medical".
 *
 * For unknown domains, returns general demos.
 */
export function get_demos_for_domain(domain: string): string;

/**
 * Get end activities with frequencies from an event log JSON.
 *
 * Returns JSON: `[{"activity":"C","count":2}, ...]`
 *
 * Mirrors `pm4py.get_end_activities()`.
 */
export function get_end_activities(log_json: string): string;

/**
 * Get all event attribute keys with their statistics.
 *
 * Returns JSON: `[{"name":"concept:name","count":7,"unique_values":3}, ...]`
 *
 * Mirrors `pm4py.get_event_attributes()`.
 */
export function get_event_attributes(log_json: string): string;

/**
 * Get minimum self-distances for each activity.
 *
 * Returns JSON: `[{"activity":"A","min_distance_ms":300000}, ...]`
 *
 * Mirrors `pm4py.get_minimum_self_distances()`.
 */
export function get_minimum_self_distances(log_json: string): string;

/**
 * Return the raw ordering relation of a `StrictPartialOrder` node as a
 * [`BinaryRelationJs`].
 *
 * # Errors
 * Throws if `spo_arena_idx` does not point to a `StrictPartialOrder`.
 */
export function get_order_of(model: PowlModel, spo_arena_idx: number): BinaryRelationJs;

/**
 * Get performance statistics for an event log.
 *
 * Returns JSON with `total_cases`, `total_events`, `avg_case_duration_ms`,
 * `min_case_duration_ms`, `max_case_duration_ms`, `median_case_duration_ms`,
 * `total_events_longest_case`, `avg_events_per_case`.
 */
export function get_performance_stats(log_json: string): string;

/**
 * Get all prefixes (partial traces) from the log with their frequencies.
 *
 * Returns JSON: `[{"prefix":["A"],"count":3,"percentage":50.0}, ...]`
 *
 * Mirrors `pm4py.get_prefixes_from_log()`.
 */
export function get_prefixes_from_log(log_json: string): string;

/**
 * Get cases per activity that show rework (activity appears more than once).
 *
 * Returns JSON: `[{"activity":"A","rework_cases":2,"total_cases":3}, ...]`
 *
 * Mirrors `pm4py.get_rework_cases_per_activity()`.
 */
export function get_rework_cases_per_activity(log_json: string): string;

/**
 * Get rework times (time between consecutive same-activity events in a case).
 *
 * Returns JSON: `[{"case_id":"1","activity":"A","duration_ms":60000}, ...]`
 *
 * Mirrors `pm4py.get_rework_times()`.
 */
export function get_rework_times(log_json: string): string;

/**
 * Get start activities with frequencies from an event log JSON.
 *
 * Returns JSON: `[{"activity":"A","count":3}, ...]`
 *
 * Mirrors `pm4py.get_start_activities()`.
 */
export function get_start_activities(log_json: string): string;

/**
 * Get trace attribute values with frequencies.
 *
 * Returns JSON: `[{"attribute":"concept:name","value":"1","count":1}, ...]`
 *
 * Mirrors `pm4py.get_trace_attribute_values()`.
 */
export function get_trace_attribute_values(log_json: string, attribute_key: string): string;

/**
 * Get all trace attribute keys with their statistics.
 *
 * Returns JSON: `[{"name":"case_id","count":3,"unique_values":3}, ...]`
 *
 * Mirrors `pm4py.get_trace_attributes()`.
 */
export function get_trace_attributes(log_json: string): string;

/**
 * Get all variants (activity sequences) with frequencies and percentages.
 *
 * Returns JSON: `[{"activities":["A","B"],"count":1,"percentage":33.3}, ...]`
 *
 * Mirrors `pm4py.get_variants()`.
 */
export function get_variants(log_json: string): string;

/**
 * Get variants as tuples (activity sequences with count).
 *
 * Returns JSON: `[{"activities":["A","B"],"count":1}, ...]`
 *
 * Mirrors `pm4py.get_variants_as_tuples()`.
 */
export function get_variants_as_tuples(log_json: string): string;

/**
 * Get variants with path durations (total, min, max, avg).
 *
 * Returns JSON: `[{"activities":["A","B"],"count":1,"total_duration_ms":300000,...}, ...]`
 *
 * Mirrors `pm4py.get_variants_paths_duration()`.
 */
export function get_variants_paths_duration(log_json: string): string;

/**
 * Convert a Heuristics Net to a Petri Net.
 *
 * Returns JSON with places, transitions, and arcs.
 *
 * # Arguments
 * * `net_json` - Heuristics net JSON (from discover_heuristics_miner)
 */
export function heuristics_to_petri_net(net_json: string): string;

/**
 * Compute complexity metrics for a POWL model and return JSON.
 *
 * Returns a JSON object with `cyclomatic`, `cfc`, `cognitive`, `nesting_depth`,
 * `branching_factor`, `activity_count`, `node_count`, and `halstead` fields.
 *
 * # Errors
 * Throws if `model` is empty.
 */
export function measure_complexity(model: PowlModel): string;

/**
 * Return a JSON string describing the node at `arena_idx`.
 *
 * Format: `{"type":"Transition","label":"A"}` or
 *         `{"type":"StrictPartialOrder","children":[0,1],"edges":[[0,1]]}`
 */
export function node_info_json(model: PowlModel, arena_idx: number): string;

/**
 * Return the string representation of an individual node by arena index.
 */
export function node_to_string(model: PowlModel, arena_idx: number): string;

/**
 * Flatten an OCEL to a traditional event log by object type.
 *
 * Input: OCEL JSON string and object type name.
 * Output: Traditional EventLog JSON (traces with case_id and events).
 *
 * The resulting log can be used with all standard discovery functions:
 * - discover_dfg()
 * - discover_petri_net_alpha_plus()
 * - inductive_miner()
 *
 * Mirrors `pm4py.ocel_flattening()`.
 */
export function ocel_flatten_by_object_type(ocel_json: string, object_type: string): string;

/**
 * Get all event types (activities) in an OCEL.
 *
 * Input: OCEL JSON string.
 * Output: JSON array of activity names.
 *
 * Mirrors `pm4py.ocel_event_types`.
 */
export function ocel_get_event_types(ocel_json: string): string;

/**
 * Get all object types in an OCEL.
 *
 * Input: OCEL JSON string.
 * Output: JSON array of object type names.
 *
 * Mirrors `pm4py.ocel_object_types`.
 */
export function ocel_get_object_types(ocel_json: string): string;

/**
 * Get a summary of an OCEL.
 *
 * Input: OCEL JSON string.
 * Output: JSON with event_count, object_count, relation_count, object_types, etc.
 *
 * Mirrors `pm4py.ocel_summary()`.
 */
export function ocel_get_summary(ocel_json: string): string;

/**
 * Parse a CSV string (with headers) and return the event log as a JSON string.
 *
 * Required columns: `case_id` / `case:concept:name`, `concept:name` / `activity`.
 * Optional: `time:timestamp` / `timestamp`.
 *
 * # Errors
 * Throws a JavaScript `Error` on parse failure.
 */
export function parse_csv_log(csv: string): string;

/**
 * Parse an OCEL from JSON string (JSON-OCEL format).
 *
 * Input: OCEL JSON string (JSON-OCEL 1.0 or 2.0 format).
 * Output: Serialized OCEL object with events, objects, relations, and globals.
 *
 * Returns the same JSON format (round-trips through parse/serialize).
 *
 * Mirrors `pm4py.read_ocel()`.
 */
export function parse_ocel_json(ocel_json: string): string;

/**
 * Parse a POWL model string (the same format as the Python `__repr__`) and
 * return an opaque [`PowlModel`] handle.
 *
 * # Errors
 * Throws a JavaScript `Error` if parsing fails.
 */
export function parse_powl(s: string): PowlModel;

/**
 * Parse a XES-formatted XML string and return the event log as a JSON string.
 *
 * # Errors
 * Throws a JavaScript `Error` on parse failure.
 */
export function parse_xes_log(xml: string): string;

/**
 * Simulate an event log from a process tree using playout.
 *
 * Generates synthetic traces by executing the process tree structure.
 * This is useful for testing, generating training data, and validating models.
 *
 * Returns JSON with `traces` array, each containing `case_id` and `events`.
 *
 * Mirrors `pm4py.play_out()` for process trees.
 *
 * # Arguments
 * * `process_tree_json` - Process tree JSON (from `powl_to_process_tree`)
 * * `num_traces` - Number of traces to generate (default: 100)
 * * `include_timestamps` - Whether to include timestamps (default: true)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function play_out(process_tree_json: string, num_traces: number, include_timestamps: boolean): string;

/**
 * Simulate an event log from a directly-follows graph using playout.
 *
 * Generates synthetic traces by random walk through the DFG structure.
 * This is useful for testing and generating synthetic data.
 *
 * Returns JSON with `traces` array, each containing `case_id` and `events`.
 *
 * Mirrors `pm4py.play_out()` for DFGs.
 *
 * # Arguments
 * * `dfg_json` - DFG JSON (from `discover_dfg`)
 * * `start_activities_json` - Start activities JSON array
 * * `end_activities_json` - End activities JSON array
 * * `num_traces` - Number of traces to generate (default: 100)
 * * `include_timestamps` - Whether to include timestamps (default: true)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function play_out_dfg(dfg_json: string, start_activities_json: string, end_activities_json: string, num_traces: number, include_timestamps: boolean): string;

/**
 * Convert a POWL model string to BPMN 2.0 XML.
 *
 * Returns a complete `<definitions>` XML document importable by Camunda,
 * bpmn.io, Signavio, and other BPMN-compliant tools.
 *
 * # Errors
 * Throws on parse failure.
 */
export function powl_to_bpmn(s: string): string;

/**
 * Convert a POWL model to Petri net and return the result as a JSON string.
 *
 * Convenience wrapper combining `parse_powl` + conversion in one call.
 *
 * # Errors
 * Throws on parse or conversion failure.
 */
export function powl_to_petri_net(s: string): string;

/**
 * Convert a POWL model string to a process tree.
 *
 * Returns JSON with `label`, `operator`, and `children` fields.
 * Leaf nodes have `label` set; internal nodes have `operator` set
 * to one of: "->" (sequence), "X" (xor), "+" (parallel), "*" (loop).
 *
 * Mirrors `pm4py.convert_to_process_tree()`.
 *
 * # Errors
 * Throws on parse failure.
 */
export function powl_to_process_tree(powl_string: string): string;

/**
 * Return the string representation of the model root (mirrors Python `__repr__`).
 */
export function powl_to_string(model: PowlModel): string;

/**
 * Convert a POWL model string to YAWL v6 XML.
 *
 * Returns a complete YAWL specification document importable by the
 * YAWL workflow engine.
 *
 * # Errors
 * Throws on parse failure.
 */
export function powl_to_yawl(s: string): string;

/**
 * Compute ETConformance precision of `log_json` against `petri_net_json`.
 *
 * Returns JSON:
 * ```json
 * {
 *   "precision": 0.85,
 *   "total_escaping": 5,
 *   "total_consumed": 100,
 *   "total_traces": 10
 * }
 * ```
 *
 * Precision measures how precisely the model describes observed behavior.
 * A score of 1.0 means the model allows exactly the behavior seen in the log.
 * A lower score means the model permits transitions that were never used
 * (escaping edges).
 *
 * Mirrors `pm4py.precision_etconformance()`.
 *
 * # Errors
 * Throws if either JSON input cannot be deserialised.
 */
export function precision_etconformance(petri_net_json: string, log_json: string): string;

/**
 * Convert a process tree (JSON) to a POWL model string.
 *
 * Takes the JSON output from `powl_to_process_tree` and converts it
 * back to a POWL model string that can be parsed with `parse_powl`.
 *
 * Note: Sequence and Parallel operators are converted to StrictPartialOrder.
 *
 * Mirrors `pm4py.convert_to_powl()` from process tree.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function process_tree_to_powl(process_tree_json: string): string;

/**
 * Project an event log to keep only the specified attributes.
 *
 * `attributes_json` is a JSON array of attribute key strings.
 * The `concept:name` (activity name) attribute is always preserved.
 *
 * Mirrors `pm4py.project_log()`.
 */
export function project_log(log_json: string, attributes_json: string): string;

/**
 * Parse a BPMN 2.0 XML string and convert to a POWL model string.
 *
 * Returns a POWL model string that can be parsed with `parse_powl`.
 * Handles both pm4wasm-generated BPMN (with `pm4py:connector`/`pm4py:silent`
 * markers) and generic BPMN from external tools (Camunda, bpmn.io, Signavio).
 *
 * Mirrors `pm4py.read_bpmn()`.
 *
 * # Errors
 * Throws on parse failure or invalid BPMN structure.
 */
export function read_bpmn(bpmn_xml: string): string;

/**
 * Deserialize a DFG from a JSON string.
 *
 * Validates the JSON structure and returns the DFG result as JSON.
 *
 * Mirrors `pm4py.read_dfg()`.
 */
export function read_dfg(dfg_json: string): string;

/**
 * Reduce a Petri net by applying structural reduction rules.
 *
 * Applies fusion of series places, fusion of series transitions,
 * elimination of self-loop places, and other reduction rules.
 *
 * Returns the reduced Petri net as JSON (same format as discovery functions).
 *
 * Mirrors `pm4py.reduce_petri_net()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function reduce_petri_net(petri_net_json: string): string;

/**
 * Replace activity labels in a POWL model.
 *
 * # Arguments
 * * `model_str` - POWL model string representation
 * * `label_map_json` - JSON string mapping old labels to new labels (e.g., {"A": "Start", "B": "End"})
 *
 * # Returns
 * * New POWL model string with labels replaced
 *
 * # Example
 * ```javascript
 * const powl = await Powl.init();
 * const result = powl.replaceLabels("X(A, B)", '{"A": "X", "B": "Y"}');
 * // Returns: "X ( X, Y )"
 * ```
 */
export function replace_labels(model_str: string, label_map_json: string): string;

/**
 * Compute simplicity metric for a Petri net.
 *
 * Simplicity measures how "simple" a model is based on its structure.
 * Uses the arc_degree variant: 1 - (arcs / (places * transitions)).
 * Returns a value in [0.0, 1.0] where 1.0 is simplest.
 *
 * Mirrors `pm4py.analysis.simplicity_petri_net()` with variant="arc_degree".
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 */
export function simplicity_petri_net(petri_net_json: string): number;

/**
 * Convert `XOR(A, tau)` / `LOOP(A, tau)` patterns to `FrequentTransition`
 * nodes.  Returns a new [`PowlModel`].
 */
export function simplify_frequent_transitions(model: PowlModel): PowlModel;

/**
 * Recursively simplify the model (merge XOR+LOOP patterns, flatten nested
 * XORs, inline sub-SPOs where possible).  Returns a new [`PowlModel`].
 */
export function simplify_powl(model: PowlModel): PowlModel;

/**
 * Sort an event log by case_id then timestamp.
 *
 * Returns the sorted event log as JSON.
 *
 * Mirrors `pm4py.sort_log()`.
 */
export function sort_log(log_json: string): string;

/**
 * Set up the `console_error_panic_hook` in debug/dev builds so Rust panics
 * surface as useful browser console messages.  Call once after `init()`.
 */
export function start(): void;

/**
 * Create a streaming conformance checker from a POWL model.
 *
 * Returns a handle that can be used with `streaming_push_trace` and `streaming_snapshot`.
 *
 * # Arguments
 * * `model_str` - POWL model string representation
 *
 * # Returns
 * * Handle ID for the streaming conformance checker
 *
 * # Example
 * ```javascript
 * const handle = streamingCreate("PO=(nodes={A, B}, order={A-->B})");
 * streamingPushTrace(handle, JSON.stringify({case_id: "1", events: [{name: "A"}, {name: "B"}]}));
 * const result = streamingSnapshot(handle);
 * console.log("Fitness:", result.fitness);
 * ```
 */
export function streaming_create(model_str: string): number;

/**
 * Push a trace to the streaming conformance checker.
 *
 * # Arguments
 * * `handle` - Handle ID from `streaming_create`
 * * `trace_json` - JSON string of a Trace object
 *
 * # Returns
 * * JSON string with current fitness and alerts
 */
export function streaming_push_trace(_handle: number, _trace_json: string): string;

/**
 * Get current snapshot of streaming conformance metrics.
 *
 * # Arguments
 * * `handle` - Handle ID from `streaming_create`
 *
 * # Returns
 * * JSON string with current fitness, traces seen, perfect rate, and any drift alerts
 */
export function streaming_snapshot(_handle: number): string;

/**
 * Convert a PetriNetResult (JSON) to PNML 2.0 XML format.
 *
 * Takes the JSON output from `powl_to_petri_net` or `discover_petri_net_inductive`
 * and converts it to PNML XML for import into tools like PNEditor, WoPeD, or ProM.
 *
 * Mirrors `pm4py.write_pnml()`.
 *
 * # Errors
 * Throws if the PetriNetResult JSON cannot be parsed.
 */
export function to_pnml(petri_net_json: string): string;

/**
 * Convert a PetriNetResult (JSON) to PNML 2.0 XML format.
 *
 * # WASM Export
 *
 * # Arguments
 * * `pn_json` - JSON string of PetriNetResult
 *
 * # Returns
 * * PNML XML string
 *
 * # Errors
 * * Returns JsValue error if JSON parsing fails
 */
export function to_pnml_json(pn_json: string): string;

/**
 * WASM export: ProcessTree JSON to PTML.
 */
export function to_ptml_json(tree_json: string): string;

/**
 * Compute token-replay fitness of `log_json` (output of [`parse_xes_log`] /
 * [`parse_csv_log`]) against `petri_net_json` (output of [`powl_to_petri_net`]).
 *
 * Returns a JSON string with shape:
 * ```json
 * {
 *   "percentage": 0.97,
 *   "avg_trace_fitness": 0.96,
 *   "perfectly_fitting_traces": 42,
 *   "total_traces": 44,
 *   "trace_results": [...]
 * }
 * ```
 *
 * # Errors
 * Throws if either JSON input cannot be deserialised.
 */
export function token_replay_fitness(petri_net_json: string, log_json: string): string;

/**
 * Return the transitive closure of the ordering relation of a
 * `StrictPartialOrder` node.
 *
 * `spo_arena_idx` is the arena index of the SPO node (use `model.root()` for
 * the root, or another index for a nested SPO).
 *
 * # Errors
 * Throws if `spo_arena_idx` does not point to a `StrictPartialOrder`.
 */
export function transitive_closure(model: PowlModel, spo_arena_idx: number): BinaryRelationJs;

/**
 * Return the transitive reduction of the ordering relation of a
 * `StrictPartialOrder` node.
 *
 * # Errors
 * Throws if the node is not an SPO or the relation is not irreflexive.
 */
export function transitive_reduction(model: PowlModel, spo_arena_idx: number): BinaryRelationJs;

/**
 * Validate that all `StrictPartialOrder` nodes in `model` have irreflexive
 * and transitive ordering relations.
 *
 * # Errors
 * Throws a JavaScript `Error` describing the first violation found.
 */
export function validate_partial_orders(model: PowlModel): void;

/**
 * Validate a POWL model string against structural soundness criteria.
 *
 * Uses POWLJudge to check for deadlock freedom, liveness, and boundedness.
 * Returns a JSON object with `verdict` (boolean), `reasoning` (string),
 * and `violations` (array of violation strings).
 *
 * # Errors
 * Throws if the POWL string cannot be parsed.
 */
export function validate_powl_structure(model_str: string): string;

/**
 * Serialize an event log (JSON) to CSV format.
 *
 * Mirrors `pm4py.write_csv()`.
 */
export function write_csv_log(log_json: string): string;

/**
 * Serialize a DFG result to a canonical JSON string (round-trip safe).
 *
 * Takes the JSON output from `discover_dfg` and returns a pretty-printed JSON string.
 *
 * Mirrors `pm4py.write_dfg()`.
 */
export function write_dfg(dfg_json: string): string;

/**
 * Serialize an event log (JSON) to XES XML format.
 *
 * Mirrors `pm4py.write_xes()`.
 */
export function write_xes_log(log_json: string): string;
