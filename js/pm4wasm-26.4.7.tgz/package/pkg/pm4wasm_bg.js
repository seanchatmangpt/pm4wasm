/**
 * A serialisable binary relation (adjacency matrix) exposed to JavaScript.
 *
 * Construct via [`transitive_closure`], [`transitive_reduction`], or
 * [`get_order_of`].
 */
export class BinaryRelationJs {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(BinaryRelationJs.prototype);
        obj.__wbg_ptr = ptr;
        BinaryRelationJsFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BinaryRelationJsFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_binaryrelationjs_free(ptr, 0);
    }
    /**
     * Return all edges as a flat `[src0, tgt0, src1, tgt1, …]` array.
     * @returns {Uint32Array}
     */
    edges_flat() {
        const ret = wasm.binaryrelationjs_edges_flat(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Nodes with no outgoing edges.
     * @returns {Uint32Array}
     */
    end_nodes() {
        const ret = wasm.binaryrelationjs_end_nodes(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Test whether edge i→j exists.
     * @param {number} i
     * @param {number} j
     * @returns {boolean}
     */
    is_edge(i, j) {
        const ret = wasm.binaryrelationjs_is_edge(this.__wbg_ptr, i, j);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    is_irreflexive() {
        const ret = wasm.binaryrelationjs_is_irreflexive(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    is_strict_partial_order() {
        const ret = wasm.binaryrelationjs_is_strict_partial_order(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    is_transitive() {
        const ret = wasm.binaryrelationjs_is_transitive(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Number of nodes.
     * @returns {number}
     */
    n() {
        const ret = wasm.binaryrelationjs_n(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Nodes with no incoming edges.
     * @returns {Uint32Array}
     */
    start_nodes() {
        const ret = wasm.binaryrelationjs_start_nodes(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) BinaryRelationJs.prototype[Symbol.dispose] = BinaryRelationJs.prototype.free;

/**
 * Flat arena holding the entire POWL model tree.
 *
 * Construct with [`parse_powl`].  The root node is at index `model.root()`.
 */
export class PowlModel {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PowlModel.prototype);
        obj.__wbg_ptr = ptr;
        PowlModelFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PowlModelFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_powlmodel_free(ptr, 0);
    }
    /**
     * @returns {boolean}
     */
    is_empty() {
        const ret = wasm.powlmodel_is_empty(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Total number of nodes in the arena.
     * @returns {number}
     */
    len() {
        const ret = wasm.powlmodel_len(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Index of the root node.
     * @returns {number}
     */
    root() {
        const ret = wasm.powlmodel_root(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) PowlModel.prototype[Symbol.dispose] = PowlModel.prototype.free;

/**
 * Compute A* alignments for every trace in an event log against a Petri net.
 *
 * Returns JSON with `total_cost`, `avg_cost`, `trace_alignments` (per-trace breakdown).
 *
 * Mirrors `pm4py.align_log()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} petri_net_json
 * @param {string} log_json
 * @returns {string}
 */
export function align_log(petri_net_json, log_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(petri_net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.align_log(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Compute A* alignment for a single trace against a Petri net.
 *
 * Returns JSON with `cost`, `is_fit`, `moves` (each with `type`, `label`, `cost`).
 * Move types: "sync" (model+log match), "log" (log only), "model" (model only).
 *
 * Mirrors `pm4py.align_trace()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} petri_net_json
 * @param {string} trace_json
 * @returns {string}
 */
export function align_trace(petri_net_json, trace_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(petri_net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(trace_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.align_trace(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Check whether a Petri net is sound (deadlock-free, bounded, liveness).
 *
 * Returns JSON: `{"sound":true,"deadlock_free":true,"bounded":true,"liveness":true}`
 *
 * Mirrors `pm4py.check_soundness()`.
 * @param {string} petri_net_json
 * @returns {string}
 */
export function check_soundness(petri_net_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(petri_net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.check_soundness(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Check temporal conformance between an event log and a temporal profile.
 *
 * Returns JSON with fitness, deviations count, and detailed deviation list.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `profile_json` - Temporal profile JSON (from discover_temporal_profile)
 * * `zeta` - Number of standard deviations for threshold (typically 2.0)
 * @param {string} log_json
 * @param {string} profile_json
 * @param {number} zeta
 * @returns {string}
 */
export function check_temporal_conformance(log_json, profile_json, zeta) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(profile_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.check_temporal_conformance(ptr0, len0, ptr1, len1, zeta);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Compute the behavioural footprints of a POWL model.
 *
 * Returns JSON with `start_activities`, `end_activities`, `activities`,
 * `skippable`, `sequence` (directly-follows pairs), `parallel` (concurrent pairs),
 * `activities_always_happening`, and `min_trace_length`.
 *
 * Mirrors the footprint analysis from `pm4py.discover_footprints()`.
 * @param {PowlModel} model
 * @returns {string}
 */
export function compute_footprints(model) {
    let deferred2_0;
    let deferred2_1;
    try {
        _assertClass(model, PowlModel);
        const ret = wasm.compute_footprints(model.__wbg_ptr);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * Compute footprints-based conformance between an event log and a POWL model.
 *
 * Compares the log's directly-follows graph against the model's footprints to
 * compute fitness, precision, recall, and f1-score.
 *
 * Returns JSON: `{"fitness":0.95,"precision":0.85,"recall":0.90,"f1":0.87}`
 * @param {string} log_json
 * @param {string} model_str
 * @returns {string}
 */
export function conformance_footprints(log_json, model_str) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(model_str, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.conformance_footprints(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Count the number of reducible elements in a Petri net.
 *
 * Returns the count of elements that could be reduced by `reduce_petri_net()`.
 *
 * Mirrors `pm4py.count_reducible_elements()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} petri_net_json
 * @returns {number}
 */
export function count_reducible_elements(petri_net_json) {
    const ptr0 = passStringToWasm0(petri_net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.count_reducible_elements(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] >>> 0;
}

/**
 * WASM export: DFG to DOT.
 * @param {string} dfg_json
 * @returns {string}
 */
export function dfg_to_dot_wasm(dfg_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ptr0 = passStringToWasm0(dfg_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.dfg_to_dot_wasm(ptr0, len0);
        deferred2_0 = ret[0];
        deferred2_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * WASM export: DFG to JSON.
 * @param {string} dfg_json
 * @returns {string}
 */
export function dfg_to_json_wasm(dfg_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ptr0 = passStringToWasm0(dfg_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.dfg_to_json_wasm(ptr0, len0);
        deferred2_0 = ret[0];
        deferred2_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * Compute the structural and behavioural diff between two POWL model strings.
 *
 * Returns a JSON object describing added/removed activities, ordering changes,
 * structural operator changes, and an overall severity level.
 *
 * # Errors
 * Throws if either string fails to parse.
 * @param {string} model_a
 * @param {string} model_b
 * @returns {string}
 */
export function diff_models(model_a, model_b) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(model_a, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(model_b, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.diff_models(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Detect batch processing patterns in an event log.
 *
 * Returns JSON with `batches` array, each containing `type` (sequential, concurrent,
 * parallel, concurrent_parallel), `activity`, `instances` with start/end timestamps.
 *
 * Mirrors `pm4py.discover_batches()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_batches(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_batches(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a BPMN model directly from an event log using the inductive miner.
 *
 * Returns a complete BPMN 2.0 XML document. Combines inductive miner discovery
 * with BPMN conversion in a single call -- no intermediate steps required.
 *
 * Mirrors `pm4py.discover_bpmn_inductive()`.
 *
 * # Errors
 * Throws if the event log JSON cannot be parsed.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_bpmn_inductive(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_bpmn_inductive(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover causal relations from a directly-follows graph (alpha variant).
 *
 * Causal relations identify which activities have a one-way dependency:
 * - A → B is causal if A always precedes B (B never precedes A)
 *
 * Returns JSON with `relations` map: (from, to) → 1 (binary causal indicator).
 *
 * Mirrors `pm4py.discover_causal()` with variant="alpha".
 *
 * # Arguments
 * * `dfg_json` - DFG JSON (from `discover_dfg`)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} dfg_json
 * @returns {string}
 */
export function discover_causal_alpha(dfg_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(dfg_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_causal_alpha(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover causal relations from a directly-follows graph (heuristic variant).
 *
 * The heuristic variant uses a threshold-based approach where:
 * - Relation (A, B) is causal if its frequency is significantly higher than (B, A)
 *
 * Returns JSON with `relations` map: (from, to) → strength (0-1000).
 *
 * Mirrors `pm4py.discover_causal()` with variant="heuristic".
 *
 * # Arguments
 * * `dfg_json` - DFG JSON (from `discover_dfg`)
 * * `threshold` - Minimum ratio for causality (default: 0.8)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} dfg_json
 * @param {number} threshold
 * @returns {string}
 */
export function discover_causal_heuristic(dfg_json, threshold) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(dfg_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_causal_heuristic(ptr0, len0, threshold);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a process model using correlation mining (case-less / timestamp-based).
 *
 * Unlike other discovery algorithms, correlation mining works without case IDs
 * by detecting temporal gaps between activity occurrences.
 *
 * Returns JSON with `start_activity`, `end_activity`, `trace_count`, `edges`.
 *
 * Mirrors `pm4py.discover_correlation()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `correlation_threshold` - Gap threshold in seconds (typically 5.0-3600.0)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @param {number} correlation_threshold
 * @returns {string}
 */
export function discover_correlation(log_json, correlation_threshold) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_correlation(ptr0, len0, correlation_threshold);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a DECLARE model from an event log.
 *
 * Returns JSON with constraint templates (response, precedence, succession, etc.)
 * and their support/confidence metrics.
 *
 * Mirrors `pm4py.discover_declare()`.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_declare(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_declare(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a Directly-Follows Graph from an event log.
 *
 * Returns JSON with `edges`, `start_activities`, `end_activities`, `activities`.
 *
 * Mirrors `pm4py.discover_dfg()`.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_dfg(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_dfg(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a typed DFG (structured format) from an event log.
 *
 * Returns JSON with `graph` (from, to, frequency triples), `start_activities`,
 * `end_activities`, and `activities` (activity, frequency pairs).
 *
 * Mirrors `pm4py.discover_dfg_typed()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_dfg_typed(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_dfg_typed(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover an eventually-follows graph (all activity pairs in any trace).
 *
 * Returns JSON array of edges: `[{"source":"A","target":"C","count":2}, ...]`
 *
 * Mirrors `pm4py.discover_eventually_follows_graph()`.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_eventually_follows_graph(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_eventually_follows_graph(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover footprints from an event log.
 *
 * Computes footprints from the log's directly-follows graph.
 * Returns the same structure as `discover_footprints_from_model`.
 *
 * Mirrors `pm4py.discover_footprints()` for event logs.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_footprints_from_log(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_footprints_from_log(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover footprints from a POWL model.
 *
 * Footprints summarize the behavioral properties of a process model:
 * - Start/end activities
 * - Sequence (directly-follows) and parallel (concurrent) pairs
 * - Minimum trace length
 * - Whether activities are skippable
 *
 * Mirrors `pm4py.discover_footprints()` for POWL models.
 *
 * # Errors
 * Throws if POWL string cannot be parsed.
 * @param {string} powl_string
 * @returns {string}
 */
export function discover_footprints_from_model(powl_string) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(powl_string, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_footprints_from_model(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a Heuristics Net from an event log.
 *
 * Returns JSON with activities, dependency measures, and start/end activities.
 *
 * Mirrors `pm4py.discover_heuristics_miner()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `dependency_threshold` - Minimum dependency score (0.0 to 1.0, typically 0.5-0.9)
 * @param {string} log_json
 * @param {number} dependency_threshold
 * @returns {string}
 */
export function discover_heuristics_miner(log_json, dependency_threshold) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_heuristics_miner(ptr0, len0, dependency_threshold);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a Heuristics Net from an event log.
 *
 * Returns JSON with activities, dependencies (with dependency scores and frequencies),
 * and start/end activities. Useful for visualization of causal relations.
 *
 * Mirrors `pm4py.discover_heuristics_net()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `dependency_threshold` - Minimum dependency score for an edge (0.0 to 1.0)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @param {number} dependency_threshold
 * @returns {string}
 */
export function discover_heuristics_net(log_json, dependency_threshold) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_heuristics_net(ptr0, len0, dependency_threshold);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover footprints directly from an event log's directly-follows graph.
 *
 * Returns JSON with `start_activities`, `end_activities`, `activities`,
 * `sequence` (directly-follows pairs), and `parallel` (bidirectional pairs).
 *
 * Mirrors `pm4py.discover_footprints()` applied to a log.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_log_footprints(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_log_footprints(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a Log Skeleton from an event log.
 *
 * Returns JSON with six constraint types: equivalence, always_after, always_before,
 * never_together, directly_follows, and activ_freq.
 *
 * Mirrors `pm4py.discover_log_skeleton()`.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_log_skeleton(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_log_skeleton(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover Event-Type / Object-Type graph from an OCEL.
 *
 * Input: OCEL JSON string.
 * Output: JSON with activities, object_types, edges, and edge_frequencies.
 *
 * Mirrors `pm4py.discover_ocel_etot()`.
 * @param {string} ocel_json
 * @returns {string}
 */
export function discover_ocel_etot(ocel_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(ocel_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_ocel_etot(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a performance DFG with duration annotations on edges.
 *
 * Returns JSON with edges containing `avg_duration_ms`, `min_duration_ms`, `max_duration_ms`.
 *
 * Mirrors `pm4py.discover_performance_dfg()`.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_performance_dfg(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_performance_dfg(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover performance spectrum for a specific activity.
 *
 * Returns JSON with `activity`, `overall_stats`, `instance_data` for visualization.
 * Useful for D3.js or similar charting libraries.
 *
 * Mirrors `pm4py.discover_performance_spectrum()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @param {string} activity
 * @returns {string}
 */
export function discover_performance_spectrum(log_json, activity) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(activity, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.discover_performance_spectrum(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Discover a Petri net from an event log using the alpha miner.
 *
 * Returns the same JSON format as other discovery functions.
 *
 * Mirrors `pm4py.discover_petri_net_alpha()`.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_petri_net_alpha(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_petri_net_alpha(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a Petri net using the Alpha+ miner algorithm (extends Alpha with loop handling).
 *
 * Input: Event log JSON (same format as other discovery functions).
 * Output: PetriNetResult JSON with places, transitions, arcs, and markings.
 *
 * Returns the same JSON format as other discovery functions.
 *
 * Mirrors `pm4py.discover_petri_net_alpha_plus()`.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_petri_net_alpha_plus(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_petri_net_alpha_plus(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a Petri net using the genetic miner (evolutionary algorithm).
 *
 * Returns the same JSON format as other discovery functions: `{net, initial_marking, final_marking}`.
 * Optionally accepts a JSON config object with `population_size`, `generations`,
 * `mutation_rate`, `crossover_rate`.
 *
 * Mirrors `pm4py.discover_petri_net_genetic()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @param {string} config_json
 * @returns {string}
 */
export function discover_petri_net_genetic(log_json, config_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(config_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.discover_petri_net_genetic(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Discover a Petri net from an event log using the heuristics miner.
 *
 * The heuristics miner is more lenient than the alpha miner for handling
 * noise and incomplete data. Uses dependency measures to filter causal relations.
 *
 * Returns the same JSON format as other discovery functions: `{net, initial_marking, final_marking}`.
 *
 * Mirrors `pm4py.discover_petri_net_heuristics()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `dependency_threshold` - Minimum dependency score for an edge (0.0 to 1.0, typically 0.8-0.99)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @param {number} dependency_threshold
 * @returns {string}
 */
export function discover_petri_net_heuristics(log_json, dependency_threshold) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_petri_net_heuristics(ptr0, len0, dependency_threshold);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a Petri net using ILP miner (STUB - NOT IMPLEMENTED).
 *
 * The ILP (Integer Linear Programming) miner requires an LP solver
 * which is not available in pure WASM. This function returns an error.
 *
 * Consider using `discover_petri_net_inductive()` or `discover_petri_net_heuristics()` instead.
 *
 * Mirrors `pm4py.discover_petri_net_ilp()`.
 *
 * # Errors
 * Always throws an error explaining ILP miner is not available in WASM.
 * @param {string} _log_json
 * @param {number} _alpha
 * @returns {string}
 */
export function discover_petri_net_ilp(_log_json, _alpha) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(_log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_petri_net_ilp(ptr0, len0, _alpha);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a Petri net from an event log using the inductive miner.
 *
 * Returns the same JSON as `powl_to_petri_net`: `{net, initial_marking, final_marking}`.
 *
 * Mirrors `pm4py.discover_petri_net_inductive()`.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_petri_net_inductive(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_petri_net_inductive(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a prefix tree (trie) from an event log.
 *
 * A prefix tree represents all unique prefixes of activity sequences in the log.
 * Each node in the tree represents an activity, and paths from root represent trace prefixes.
 * Nodes that represent the end of a trace are marked as `is_final = true`.
 *
 * Returns JSON with the trie structure: nodes array with label, parent, children, is_final, depth.
 *
 * Mirrors `pm4py.discover_prefix_tree()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `max_path_length` - Optional maximum trace length (traces are truncated)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @param {number | null} [max_path_length]
 * @returns {string}
 */
export function discover_prefix_tree(log_json, max_path_length) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_prefix_tree(ptr0, len0, isLikeNone(max_path_length) ? 0x100000001 : (max_path_length) >>> 0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a process tree using the inductive miner.
 *
 * Returns a JSON representation of the process tree with `label`, `operator`,
 * and `children` fields. Leaf nodes have `label` set; internal nodes have
 * `operator` set to one of: `"->"`, `"X"`, `"+"`, `"*"`.
 *
 * Mirrors `pm4py.discover_process_tree_inductive()`.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_process_tree_inductive(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_process_tree_inductive(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a temporal profile from an event log.
 *
 * Returns JSON with directly-follows pairs and their mean/stdev duration in ms.
 *
 * Mirrors `pm4py.discover_temporal_profile()`.
 * @param {string} log_json
 * @returns {string}
 */
export function discover_temporal_profile(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.discover_temporal_profile(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Discover a transition system from an event log.
 *
 * A transition system is a state machine that captures all observed behavior:
 * - Each state represents a "view" of the trace (window of recent activities)
 * - Transitions represent activity executions that move between states
 *
 * Returns JSON with `states` (id, name) and `transitions` (from_state, to_state, activity, count).
 *
 * Mirrors `pm4py.discover_transition_system()`.
 *
 * # Arguments
 * * `log_json` - Event log JSON
 * * `window` - Size of the lookback window (default: 2)
 * * `direction` - "forward" (default) or "backward" direction
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @param {number} window
 * @param {string} direction
 * @returns {string}
 */
export function discover_transition_system(log_json, window, direction) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(direction, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.discover_transition_system(ptr0, len0, window, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Filter log to keep only traces between two activities.
 *
 * Keeps traces that contain both activities and where `act1` appears before `act2`.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_between()`.
 * @param {string} log_json
 * @param {string} act1
 * @param {string} act2
 * @returns {string}
 */
export function filter_between(log_json, act1, act2) {
    let deferred5_0;
    let deferred5_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(act1, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(act2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.filter_between(ptr0, len0, ptr1, len1, ptr2, len2);
        var ptr4 = ret[0];
        var len4 = ret[1];
        if (ret[3]) {
            ptr4 = 0; len4 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred5_0 = ptr4;
        deferred5_1 = len4;
        return getStringFromWasm0(ptr4, len4);
    } finally {
        wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
    }
}

/**
 * Filter log to keep only traces within a case size range.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_case_size()`.
 * @param {string} log_json
 * @param {number} min_size
 * @param {number} max_size
 * @returns {string}
 */
export function filter_case_size(log_json, min_size, max_size) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.filter_case_size(ptr0, len0, min_size, max_size);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Filter log to keep only traces containing a specific activity relation.
 *
 * Keeps traces where activity `a` is directly followed by activity `b`.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_directly_follows_relation()`.
 * @param {string} log_json
 * @param {string} a
 * @param {string} b
 * @returns {string}
 */
export function filter_directly_follows_relation(log_json, a, b) {
    let deferred5_0;
    let deferred5_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(a, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(b, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.filter_directly_follows_relation(ptr0, len0, ptr1, len1, ptr2, len2);
        var ptr4 = ret[0];
        var len4 = ret[1];
        if (ret[3]) {
            ptr4 = 0; len4 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred5_0 = ptr4;
        deferred5_1 = len4;
        return getStringFromWasm0(ptr4, len4);
    } finally {
        wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
    }
}

/**
 * Filter log to keep only traces ending with specified activities.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_end_activities()`.
 * @param {string} log_json
 * @param {string} activities_json
 * @returns {string}
 */
export function filter_end_activities(log_json, activities_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(activities_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.filter_end_activities(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Filter log to keep only traces starting with a specific prefix.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_prefixes()`.
 * @param {string} log_json
 * @param {string} prefix_json
 * @returns {string}
 */
export function filter_prefixes(log_json, prefix_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(prefix_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.filter_prefixes(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Filter log to keep only traces starting with specified activities.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_start_activities()`.
 * @param {string} log_json
 * @param {string} activities_json
 * @returns {string}
 */
export function filter_start_activities(log_json, activities_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(activities_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.filter_start_activities(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Filter log to keep only traces ending with a specific suffix.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_suffixes()`.
 * @param {string} log_json
 * @param {string} suffix_json
 * @returns {string}
 */
export function filter_suffixes(log_json, suffix_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(suffix_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.filter_suffixes(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Filter log to keep only events within a time range.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_time_range()`.
 * @param {string} log_json
 * @param {bigint} start_ms
 * @param {bigint} end_ms
 * @returns {string}
 */
export function filter_time_range(log_json, start_ms, end_ms) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.filter_time_range(ptr0, len0, start_ms, end_ms);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Trim traces to remove events before the first start activity and after the last end activity.
 *
 * Mirrors `pm4py.filter_trim()`.
 * @param {string} log_json
 * @param {string} start_activity
 * @param {string} end_activity
 * @returns {string}
 */
export function filter_trim(log_json, start_activity, end_activity) {
    let deferred5_0;
    let deferred5_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(start_activity, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(end_activity, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.filter_trim(ptr0, len0, ptr1, len1, ptr2, len2);
        var ptr4 = ret[0];
        var len4 = ret[1];
        if (ret[3]) {
            ptr4 = 0; len4 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred5_0 = ptr4;
        deferred5_1 = len4;
        return getStringFromWasm0(ptr4, len4);
    } finally {
        wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
    }
}

/**
 * Filter log to keep only variants covering at least a percentage of traces.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_variants_by_coverage_percentage()`.
 * @param {string} log_json
 * @param {number} min_coverage
 * @returns {string}
 */
export function filter_variants_coverage(log_json, min_coverage) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.filter_variants_coverage(ptr0, len0, min_coverage);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Filter log to keep only the top K most frequent variants.
 *
 * Returns filtered log as JSON.
 *
 * Mirrors `pm4py.filter_variants_top_k()`.
 * @param {string} log_json
 * @param {number} k
 * @returns {string}
 */
export function filter_variants_top_k(log_json, k) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.filter_variants_top_k(ptr0, len0, k);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Compute footprints-based conformance diagnostics.
 *
 * Compares the log's directly-follows graph against a model's footprints
 * to compute fitness, precision, recall, and f1-score.
 *
 * Returns JSON: `{"fitness": 0.95, "precision": 0.85, "recall": 0.95, "f1": 0.90}`
 *
 * Mirrors `pm4py.conformance_diagnostics_footprints()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @param {string} model_fp_json
 * @returns {string}
 */
export function footprints_diagnostics(log_json, model_fp_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(model_fp_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.footprints_diagnostics(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Compute footprints-based fitness.
 *
 * Fraction of the log's directly-follows pairs that are allowed by the model.
 * Returns a value in [0.0, 1.0] where 1.0 is perfect fitness.
 *
 * Mirrors `pm4py.fitness_footprints()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @param {string} model_fp_json
 * @returns {number}
 */
export function footprints_fitness(log_json, model_fp_json) {
    const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(model_fp_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.footprints_fitness(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0];
}

/**
 * Compute footprints-based precision.
 *
 * Fraction of the model's directly-follows pairs that are observed in the log.
 * Returns a value in [0.0, 1.0] where 1.0 is perfect precision.
 *
 * Mirrors `pm4py.precision_footprints()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} log_json
 * @param {string} model_fp_json
 * @returns {number}
 */
export function footprints_precision(log_json, model_fp_json) {
    const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(model_fp_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.footprints_precision(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0];
}

/**
 * Import a PNML 2.0 XML string into a PetriNetResult JSON.
 *
 * Mirrors `pm4py.read_pnml()`.
 *
 * # Errors
 * Throws if the PNML XML cannot be parsed.
 * @param {string} xml
 * @returns {string}
 */
export function from_pnml(xml) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.from_pnml(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parse a PNML XML string (JSON-free) for WASM consumers.
 * @param {string} xml
 * @returns {string}
 */
export function from_pnml_string(xml) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.from_pnml_string(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * WASM export: PTML to ProcessTree JSON.
 * @param {string} xml
 * @returns {string}
 */
export function from_ptml_string(xml) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.from_ptml_string(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Compute generalization quality metric for a Petri net against an event log.
 *
 * Returns JSON with `generalization` score in [0.0, 1.0].
 * Higher scores indicate the model generalizes well (not overfitting).
 *
 * Mirrors `pm4py.generalization()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} petri_net_json
 * @param {string} log_json
 * @returns {string}
 */
export function generalization(petri_net_json, log_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(petri_net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.generalization(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Generate executable code from a POWL model string.
 *
 * Converts POWL to n8n JSON, Temporal Go, Camunda BPMN, or YAWL v6 XML.
 *
 * # Errors
 * Throws if the POWL string cannot be parsed or if the target is unknown.
 * @param {string} model_str
 * @param {string} target
 * @returns {string}
 */
export function generate_code_from_powl(model_str, target) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(model_str, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(target, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.generate_code_from_powl(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Get all case durations as a flat JSON array of milliseconds.
 *
 * Returns JSON: `[300000, 600000, 1800000, ...]`
 *
 * Mirrors `pm4py.get_all_case_durations()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_all_case_durations(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_all_case_durations(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get all distinct values for a given event attribute with frequencies.
 *
 * Returns JSON: `[{"attribute":"concept:name","value":"A","count":3}, ...]`
 *
 * Mirrors `pm4py.get_attribute_values()`.
 * @param {string} log_json
 * @param {string} attribute_key
 * @returns {string}
 */
export function get_attribute_values(log_json, attribute_key) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(attribute_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.get_attribute_values(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Get the average case arrival rate (cases per hour).
 *
 * Mirrors `pm4py.get_case_arrival_average()`.
 * @param {string} log_json
 * @returns {number}
 */
export function get_case_arrival_average(log_json) {
    const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.get_case_arrival_average(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0];
}

/**
 * Get case attributes with their statistics.
 *
 * Returns JSON: `[{"name":"case_id","count":3,"unique_values":3}, ...]`
 *
 * Mirrors `pm4py.get_case_attributes()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_case_attributes(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_case_attributes(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get case durations as JSON.
 *
 * Returns JSON: `[{"case_id":"1","duration_ms":300000}, ...]`
 *
 * Mirrors `pm4py.get_case_durations()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_case_durations(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_case_durations(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get case overlap (fraction of shared prefixes between traces, 0.0–1.0).
 *
 * Mirrors `pm4py.get_case_overlap()`.
 * @param {string} log_json
 * @returns {number}
 */
export function get_case_overlap(log_json) {
    const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.get_case_overlap(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0];
}

/**
 * Return the child arena indices of an SPO or OperatorPOWL node as a flat
 * `u32` array.  Returns an empty array for leaf nodes.
 * @param {PowlModel} model
 * @param {number} arena_idx
 * @returns {Uint32Array}
 */
export function get_children(model, arena_idx) {
    _assertClass(model, PowlModel);
    const ret = wasm.get_children(model.__wbg_ptr, arena_idx);
    var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
    return v1;
}

/**
 * Get few-shot demos for a specific domain.
 *
 * Returns a JSON array of few-shot examples for LLM-guided POWL generation.
 * Supported domains: "loan_approval", "finance", "software_release", "it",
 * "devops", "ecommerce", "retail", "manufacturing", "production",
 * "healthcare", "medical".
 *
 * For unknown domains, returns general demos.
 * @param {string} domain
 * @returns {string}
 */
export function get_demos_for_domain(domain) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ptr0 = passStringToWasm0(domain, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_demos_for_domain(ptr0, len0);
        deferred2_0 = ret[0];
        deferred2_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * Get end activities with frequencies from an event log JSON.
 *
 * Returns JSON: `[{"activity":"C","count":2}, ...]`
 *
 * Mirrors `pm4py.get_end_activities()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_end_activities(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_end_activities(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get all event attribute keys with their statistics.
 *
 * Returns JSON: `[{"name":"concept:name","count":7,"unique_values":3}, ...]`
 *
 * Mirrors `pm4py.get_event_attributes()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_event_attributes(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_event_attributes(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get minimum self-distances for each activity.
 *
 * Returns JSON: `[{"activity":"A","min_distance_ms":300000}, ...]`
 *
 * Mirrors `pm4py.get_minimum_self_distances()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_minimum_self_distances(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_minimum_self_distances(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Return the raw ordering relation of a `StrictPartialOrder` node as a
 * [`BinaryRelationJs`].
 *
 * # Errors
 * Throws if `spo_arena_idx` does not point to a `StrictPartialOrder`.
 * @param {PowlModel} model
 * @param {number} spo_arena_idx
 * @returns {BinaryRelationJs}
 */
export function get_order_of(model, spo_arena_idx) {
    _assertClass(model, PowlModel);
    const ret = wasm.get_order_of(model.__wbg_ptr, spo_arena_idx);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return BinaryRelationJs.__wrap(ret[0]);
}

/**
 * Get performance statistics for an event log.
 *
 * Returns JSON with `total_cases`, `total_events`, `avg_case_duration_ms`,
 * `min_case_duration_ms`, `max_case_duration_ms`, `median_case_duration_ms`,
 * `total_events_longest_case`, `avg_events_per_case`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_performance_stats(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_performance_stats(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get all prefixes (partial traces) from the log with their frequencies.
 *
 * Returns JSON: `[{"prefix":["A"],"count":3,"percentage":50.0}, ...]`
 *
 * Mirrors `pm4py.get_prefixes_from_log()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_prefixes_from_log(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_prefixes_from_log(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get cases per activity that show rework (activity appears more than once).
 *
 * Returns JSON: `[{"activity":"A","rework_cases":2,"total_cases":3}, ...]`
 *
 * Mirrors `pm4py.get_rework_cases_per_activity()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_rework_cases_per_activity(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_rework_cases_per_activity(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get rework times (time between consecutive same-activity events in a case).
 *
 * Returns JSON: `[{"case_id":"1","activity":"A","duration_ms":60000}, ...]`
 *
 * Mirrors `pm4py.get_rework_times()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_rework_times(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_rework_times(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get start activities with frequencies from an event log JSON.
 *
 * Returns JSON: `[{"activity":"A","count":3}, ...]`
 *
 * Mirrors `pm4py.get_start_activities()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_start_activities(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_start_activities(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get trace attribute values with frequencies.
 *
 * Returns JSON: `[{"attribute":"concept:name","value":"1","count":1}, ...]`
 *
 * Mirrors `pm4py.get_trace_attribute_values()`.
 * @param {string} log_json
 * @param {string} attribute_key
 * @returns {string}
 */
export function get_trace_attribute_values(log_json, attribute_key) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(attribute_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.get_trace_attribute_values(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Get all trace attribute keys with their statistics.
 *
 * Returns JSON: `[{"name":"case_id","count":3,"unique_values":3}, ...]`
 *
 * Mirrors `pm4py.get_trace_attributes()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_trace_attributes(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_trace_attributes(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get all variants (activity sequences) with frequencies and percentages.
 *
 * Returns JSON: `[{"activities":["A","B"],"count":1,"percentage":33.3}, ...]`
 *
 * Mirrors `pm4py.get_variants()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_variants(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_variants(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get variants as tuples (activity sequences with count).
 *
 * Returns JSON: `[{"activities":["A","B"],"count":1}, ...]`
 *
 * Mirrors `pm4py.get_variants_as_tuples()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_variants_as_tuples(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_variants_as_tuples(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get variants with path durations (total, min, max, avg).
 *
 * Returns JSON: `[{"activities":["A","B"],"count":1,"total_duration_ms":300000,...}, ...]`
 *
 * Mirrors `pm4py.get_variants_paths_duration()`.
 * @param {string} log_json
 * @returns {string}
 */
export function get_variants_paths_duration(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.get_variants_paths_duration(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Convert a Heuristics Net to a Petri Net.
 *
 * Returns JSON with places, transitions, and arcs.
 *
 * # Arguments
 * * `net_json` - Heuristics net JSON (from discover_heuristics_miner)
 * @param {string} net_json
 * @returns {string}
 */
export function heuristics_to_petri_net(net_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.heuristics_to_petri_net(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Compute complexity metrics for a POWL model and return JSON.
 *
 * Returns a JSON object with `cyclomatic`, `cfc`, `cognitive`, `nesting_depth`,
 * `branching_factor`, `activity_count`, `node_count`, and `halstead` fields.
 *
 * # Errors
 * Throws if `model` is empty.
 * @param {PowlModel} model
 * @returns {string}
 */
export function measure_complexity(model) {
    let deferred2_0;
    let deferred2_1;
    try {
        _assertClass(model, PowlModel);
        const ret = wasm.measure_complexity(model.__wbg_ptr);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * Return a JSON string describing the node at `arena_idx`.
 *
 * Format: `{"type":"Transition","label":"A"}` or
 *         `{"type":"StrictPartialOrder","children":[0,1],"edges":[[0,1]]}`
 * @param {PowlModel} model
 * @param {number} arena_idx
 * @returns {string}
 */
export function node_info_json(model, arena_idx) {
    let deferred1_0;
    let deferred1_1;
    try {
        _assertClass(model, PowlModel);
        const ret = wasm.node_info_json(model.__wbg_ptr, arena_idx);
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * Return the string representation of an individual node by arena index.
 * @param {PowlModel} model
 * @param {number} arena_idx
 * @returns {string}
 */
export function node_to_string(model, arena_idx) {
    let deferred1_0;
    let deferred1_1;
    try {
        _assertClass(model, PowlModel);
        const ret = wasm.node_to_string(model.__wbg_ptr, arena_idx);
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * Flatten an OCEL to a traditional event log by object type.
 *
 * Input: OCEL JSON string and object type name.
 * Output: Traditional EventLog JSON (traces with case_id and events).
 *
 * The resulting log can be used with all standard discovery functions:
 * - discover_dfg()
 * - discover_petri_net_alpha_plus()
 * - inductive_miner()
 *
 * Mirrors `pm4py.ocel_flattening()`.
 * @param {string} ocel_json
 * @param {string} object_type
 * @returns {string}
 */
export function ocel_flatten_by_object_type(ocel_json, object_type) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(ocel_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(object_type, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.ocel_flatten_by_object_type(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Get all event types (activities) in an OCEL.
 *
 * Input: OCEL JSON string.
 * Output: JSON array of activity names.
 *
 * Mirrors `pm4py.ocel_event_types`.
 * @param {string} ocel_json
 * @returns {string}
 */
export function ocel_get_event_types(ocel_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(ocel_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ocel_get_event_types(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get all object types in an OCEL.
 *
 * Input: OCEL JSON string.
 * Output: JSON array of object type names.
 *
 * Mirrors `pm4py.ocel_object_types`.
 * @param {string} ocel_json
 * @returns {string}
 */
export function ocel_get_object_types(ocel_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(ocel_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ocel_get_object_types(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get a summary of an OCEL.
 *
 * Input: OCEL JSON string.
 * Output: JSON with event_count, object_count, relation_count, object_types, etc.
 *
 * Mirrors `pm4py.ocel_summary()`.
 * @param {string} ocel_json
 * @returns {string}
 */
export function ocel_get_summary(ocel_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(ocel_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ocel_get_summary(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parse a CSV string (with headers) and return the event log as a JSON string.
 *
 * Required columns: `case_id` / `case:concept:name`, `concept:name` / `activity`.
 * Optional: `time:timestamp` / `timestamp`.
 *
 * # Errors
 * Throws a JavaScript `Error` on parse failure.
 * @param {string} csv
 * @returns {string}
 */
export function parse_csv_log(csv) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(csv, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_csv_log(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parse an OCEL from JSON string (JSON-OCEL format).
 *
 * Input: OCEL JSON string (JSON-OCEL 1.0 or 2.0 format).
 * Output: Serialized OCEL object with events, objects, relations, and globals.
 *
 * Returns the same JSON format (round-trips through parse/serialize).
 *
 * Mirrors `pm4py.read_ocel()`.
 * @param {string} ocel_json
 * @returns {string}
 */
export function parse_ocel_json(ocel_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(ocel_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_ocel_json(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parse a POWL model string (the same format as the Python `__repr__`) and
 * return an opaque [`PowlModel`] handle.
 *
 * # Errors
 * Throws a JavaScript `Error` if parsing fails.
 * @param {string} s
 * @returns {PowlModel}
 */
export function parse_powl(s) {
    const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parse_powl(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return PowlModel.__wrap(ret[0]);
}

/**
 * Parse a XES-formatted XML string and return the event log as a JSON string.
 *
 * # Errors
 * Throws a JavaScript `Error` on parse failure.
 * @param {string} xml
 * @returns {string}
 */
export function parse_xes_log(xml) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.parse_xes_log(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Simulate an event log from a process tree using playout.
 *
 * Generates synthetic traces by executing the process tree structure.
 * This is useful for testing, generating training data, and validating models.
 *
 * Returns JSON with `traces` array, each containing `case_id` and `events`.
 *
 * Mirrors `pm4py.play_out()` for process trees.
 *
 * # Arguments
 * * `process_tree_json` - Process tree JSON (from `powl_to_process_tree`)
 * * `num_traces` - Number of traces to generate (default: 100)
 * * `include_timestamps` - Whether to include timestamps (default: true)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} process_tree_json
 * @param {number} num_traces
 * @param {boolean} include_timestamps
 * @returns {string}
 */
export function play_out(process_tree_json, num_traces, include_timestamps) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(process_tree_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.play_out(ptr0, len0, num_traces, include_timestamps);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Simulate an event log from a directly-follows graph using playout.
 *
 * Generates synthetic traces by random walk through the DFG structure.
 * This is useful for testing and generating synthetic data.
 *
 * Returns JSON with `traces` array, each containing `case_id` and `events`.
 *
 * Mirrors `pm4py.play_out()` for DFGs.
 *
 * # Arguments
 * * `dfg_json` - DFG JSON (from `discover_dfg`)
 * * `start_activities_json` - Start activities JSON array
 * * `end_activities_json` - End activities JSON array
 * * `num_traces` - Number of traces to generate (default: 100)
 * * `include_timestamps` - Whether to include timestamps (default: true)
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} dfg_json
 * @param {string} start_activities_json
 * @param {string} end_activities_json
 * @param {number} num_traces
 * @param {boolean} include_timestamps
 * @returns {string}
 */
export function play_out_dfg(dfg_json, start_activities_json, end_activities_json, num_traces, include_timestamps) {
    let deferred5_0;
    let deferred5_1;
    try {
        const ptr0 = passStringToWasm0(dfg_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(start_activities_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(end_activities_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.play_out_dfg(ptr0, len0, ptr1, len1, ptr2, len2, num_traces, include_timestamps);
        var ptr4 = ret[0];
        var len4 = ret[1];
        if (ret[3]) {
            ptr4 = 0; len4 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred5_0 = ptr4;
        deferred5_1 = len4;
        return getStringFromWasm0(ptr4, len4);
    } finally {
        wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
    }
}

/**
 * Convert a POWL model string to BPMN 2.0 XML.
 *
 * Returns a complete `<definitions>` XML document importable by Camunda,
 * bpmn.io, Signavio, and other BPMN-compliant tools.
 *
 * # Errors
 * Throws on parse failure.
 * @param {string} s
 * @returns {string}
 */
export function powl_to_bpmn(s) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.powl_to_bpmn(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Convert a POWL model to Petri net and return the result as a JSON string.
 *
 * Convenience wrapper combining `parse_powl` + conversion in one call.
 *
 * # Errors
 * Throws on parse or conversion failure.
 * @param {string} s
 * @returns {string}
 */
export function powl_to_petri_net(s) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.powl_to_petri_net(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Convert a POWL model string to a process tree.
 *
 * Returns JSON with `label`, `operator`, and `children` fields.
 * Leaf nodes have `label` set; internal nodes have `operator` set
 * to one of: "->" (sequence), "X" (xor), "+" (parallel), "*" (loop).
 *
 * Mirrors `pm4py.convert_to_process_tree()`.
 *
 * # Errors
 * Throws on parse failure.
 * @param {string} powl_string
 * @returns {string}
 */
export function powl_to_process_tree(powl_string) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(powl_string, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.powl_to_process_tree(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Return the string representation of the model root (mirrors Python `__repr__`).
 * @param {PowlModel} model
 * @returns {string}
 */
export function powl_to_string(model) {
    let deferred1_0;
    let deferred1_1;
    try {
        _assertClass(model, PowlModel);
        const ret = wasm.powl_to_string(model.__wbg_ptr);
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * Convert a POWL model string to YAWL v6 XML.
 *
 * Returns a complete YAWL specification document importable by the
 * YAWL workflow engine.
 *
 * # Errors
 * Throws on parse failure.
 * @param {string} s
 * @returns {string}
 */
export function powl_to_yawl(s) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.powl_to_yawl(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Compute ETConformance precision of `log_json` against `petri_net_json`.
 *
 * Returns JSON:
 * ```json
 * {
 *   "precision": 0.85,
 *   "total_escaping": 5,
 *   "total_consumed": 100,
 *   "total_traces": 10
 * }
 * ```
 *
 * Precision measures how precisely the model describes observed behavior.
 * A score of 1.0 means the model allows exactly the behavior seen in the log.
 * A lower score means the model permits transitions that were never used
 * (escaping edges).
 *
 * Mirrors `pm4py.precision_etconformance()`.
 *
 * # Errors
 * Throws if either JSON input cannot be deserialised.
 * @param {string} petri_net_json
 * @param {string} log_json
 * @returns {string}
 */
export function precision_etconformance(petri_net_json, log_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(petri_net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.precision_etconformance(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Convert a process tree (JSON) to a POWL model string.
 *
 * Takes the JSON output from `powl_to_process_tree` and converts it
 * back to a POWL model string that can be parsed with `parse_powl`.
 *
 * Note: Sequence and Parallel operators are converted to StrictPartialOrder.
 *
 * Mirrors `pm4py.convert_to_powl()` from process tree.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} process_tree_json
 * @returns {string}
 */
export function process_tree_to_powl(process_tree_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(process_tree_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.process_tree_to_powl(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Project an event log to keep only the specified attributes.
 *
 * `attributes_json` is a JSON array of attribute key strings.
 * The `concept:name` (activity name) attribute is always preserved.
 *
 * Mirrors `pm4py.project_log()`.
 * @param {string} log_json
 * @param {string} attributes_json
 * @returns {string}
 */
export function project_log(log_json, attributes_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(attributes_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.project_log(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Parse a BPMN 2.0 XML string and convert to a POWL model string.
 *
 * Returns a POWL model string that can be parsed with `parse_powl`.
 * Handles both pm4wasm-generated BPMN (with `pm4py:connector`/`pm4py:silent`
 * markers) and generic BPMN from external tools (Camunda, bpmn.io, Signavio).
 *
 * Mirrors `pm4py.read_bpmn()`.
 *
 * # Errors
 * Throws on parse failure or invalid BPMN structure.
 * @param {string} bpmn_xml
 * @returns {string}
 */
export function read_bpmn(bpmn_xml) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(bpmn_xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.read_bpmn(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Deserialize a DFG from a JSON string.
 *
 * Validates the JSON structure and returns the DFG result as JSON.
 *
 * Mirrors `pm4py.read_dfg()`.
 * @param {string} dfg_json
 * @returns {string}
 */
export function read_dfg(dfg_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(dfg_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.read_dfg(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Reduce a Petri net by applying structural reduction rules.
 *
 * Applies fusion of series places, fusion of series transitions,
 * elimination of self-loop places, and other reduction rules.
 *
 * Returns the reduced Petri net as JSON (same format as discovery functions).
 *
 * Mirrors `pm4py.reduce_petri_net()`.
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} petri_net_json
 * @returns {string}
 */
export function reduce_petri_net(petri_net_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(petri_net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.reduce_petri_net(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Replace activity labels in a POWL model.
 *
 * # Arguments
 * * `model_str` - POWL model string representation
 * * `label_map_json` - JSON string mapping old labels to new labels (e.g., {"A": "Start", "B": "End"})
 *
 * # Returns
 * * New POWL model string with labels replaced
 *
 * # Example
 * ```javascript
 * const powl = await Powl.init();
 * const result = powl.replaceLabels("X(A, B)", '{"A": "X", "B": "Y"}');
 * // Returns: "X ( X, Y )"
 * ```
 * @param {string} model_str
 * @param {string} label_map_json
 * @returns {string}
 */
export function replace_labels(model_str, label_map_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(model_str, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(label_map_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.replace_labels(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Compute simplicity metric for a Petri net.
 *
 * Simplicity measures how "simple" a model is based on its structure.
 * Uses the arc_degree variant: 1 - (arcs / (places * transitions)).
 * Returns a value in [0.0, 1.0] where 1.0 is simplest.
 *
 * Mirrors `pm4py.analysis.simplicity_petri_net()` with variant="arc_degree".
 *
 * # Errors
 * Throws if JSON cannot be deserialised.
 * @param {string} petri_net_json
 * @returns {number}
 */
export function simplicity_petri_net(petri_net_json) {
    const ptr0 = passStringToWasm0(petri_net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.simplicity_petri_net(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0];
}

/**
 * Convert `XOR(A, tau)` / `LOOP(A, tau)` patterns to `FrequentTransition`
 * nodes.  Returns a new [`PowlModel`].
 * @param {PowlModel} model
 * @returns {PowlModel}
 */
export function simplify_frequent_transitions(model) {
    _assertClass(model, PowlModel);
    const ret = wasm.simplify_frequent_transitions(model.__wbg_ptr);
    return PowlModel.__wrap(ret);
}

/**
 * Recursively simplify the model (merge XOR+LOOP patterns, flatten nested
 * XORs, inline sub-SPOs where possible).  Returns a new [`PowlModel`].
 * @param {PowlModel} model
 * @returns {PowlModel}
 */
export function simplify_powl(model) {
    _assertClass(model, PowlModel);
    const ret = wasm.simplify_powl(model.__wbg_ptr);
    return PowlModel.__wrap(ret);
}

/**
 * Sort an event log by case_id then timestamp.
 *
 * Returns the sorted event log as JSON.
 *
 * Mirrors `pm4py.sort_log()`.
 * @param {string} log_json
 * @returns {string}
 */
export function sort_log(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sort_log(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Set up the `console_error_panic_hook` in debug/dev builds so Rust panics
 * surface as useful browser console messages.  Call once after `init()`.
 */
export function start() {
    wasm.start();
}

/**
 * Create a streaming conformance checker from a POWL model.
 *
 * Returns a handle that can be used with `streaming_push_trace` and `streaming_snapshot`.
 *
 * # Arguments
 * * `model_str` - POWL model string representation
 *
 * # Returns
 * * Handle ID for the streaming conformance checker
 *
 * # Example
 * ```javascript
 * const handle = streamingCreate("PO=(nodes={A, B}, order={A-->B})");
 * streamingPushTrace(handle, JSON.stringify({case_id: "1", events: [{name: "A"}, {name: "B"}]}));
 * const result = streamingSnapshot(handle);
 * console.log("Fitness:", result.fitness);
 * ```
 * @param {string} model_str
 * @returns {number}
 */
export function streaming_create(model_str) {
    const ptr0 = passStringToWasm0(model_str, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.streaming_create(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] >>> 0;
}

/**
 * Push a trace to the streaming conformance checker.
 *
 * # Arguments
 * * `handle` - Handle ID from `streaming_create`
 * * `trace_json` - JSON string of a Trace object
 *
 * # Returns
 * * JSON string with current fitness and alerts
 * @param {number} _handle
 * @param {string} _trace_json
 * @returns {string}
 */
export function streaming_push_trace(_handle, _trace_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(_trace_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.streaming_push_trace(_handle, ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Get current snapshot of streaming conformance metrics.
 *
 * # Arguments
 * * `handle` - Handle ID from `streaming_create`
 *
 * # Returns
 * * JSON string with current fitness, traces seen, perfect rate, and any drift alerts
 * @param {number} _handle
 * @returns {string}
 */
export function streaming_snapshot(_handle) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.streaming_snapshot(_handle);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * Convert a PetriNetResult (JSON) to PNML 2.0 XML format.
 *
 * Takes the JSON output from `powl_to_petri_net` or `discover_petri_net_inductive`
 * and converts it to PNML XML for import into tools like PNEditor, WoPeD, or ProM.
 *
 * Mirrors `pm4py.write_pnml()`.
 *
 * # Errors
 * Throws if the PetriNetResult JSON cannot be parsed.
 * @param {string} petri_net_json
 * @returns {string}
 */
export function to_pnml(petri_net_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(petri_net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.to_pnml(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Convert a PetriNetResult (JSON) to PNML 2.0 XML format.
 *
 * # WASM Export
 *
 * # Arguments
 * * `pn_json` - JSON string of PetriNetResult
 *
 * # Returns
 * * PNML XML string
 *
 * # Errors
 * * Returns JsValue error if JSON parsing fails
 * @param {string} pn_json
 * @returns {string}
 */
export function to_pnml_json(pn_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(pn_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.to_pnml_json(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * WASM export: ProcessTree JSON to PTML.
 * @param {string} tree_json
 * @returns {string}
 */
export function to_ptml_json(tree_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(tree_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.to_ptml_json(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Compute token-replay fitness of `log_json` (output of [`parse_xes_log`] /
 * [`parse_csv_log`]) against `petri_net_json` (output of [`powl_to_petri_net`]).
 *
 * Returns a JSON string with shape:
 * ```json
 * {
 *   "percentage": 0.97,
 *   "avg_trace_fitness": 0.96,
 *   "perfectly_fitting_traces": 42,
 *   "total_traces": 44,
 *   "trace_results": [...]
 * }
 * ```
 *
 * # Errors
 * Throws if either JSON input cannot be deserialised.
 * @param {string} petri_net_json
 * @param {string} log_json
 * @returns {string}
 */
export function token_replay_fitness(petri_net_json, log_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(petri_net_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.token_replay_fitness(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Return the transitive closure of the ordering relation of a
 * `StrictPartialOrder` node.
 *
 * `spo_arena_idx` is the arena index of the SPO node (use `model.root()` for
 * the root, or another index for a nested SPO).
 *
 * # Errors
 * Throws if `spo_arena_idx` does not point to a `StrictPartialOrder`.
 * @param {PowlModel} model
 * @param {number} spo_arena_idx
 * @returns {BinaryRelationJs}
 */
export function transitive_closure(model, spo_arena_idx) {
    _assertClass(model, PowlModel);
    const ret = wasm.transitive_closure(model.__wbg_ptr, spo_arena_idx);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return BinaryRelationJs.__wrap(ret[0]);
}

/**
 * Return the transitive reduction of the ordering relation of a
 * `StrictPartialOrder` node.
 *
 * # Errors
 * Throws if the node is not an SPO or the relation is not irreflexive.
 * @param {PowlModel} model
 * @param {number} spo_arena_idx
 * @returns {BinaryRelationJs}
 */
export function transitive_reduction(model, spo_arena_idx) {
    _assertClass(model, PowlModel);
    const ret = wasm.transitive_reduction(model.__wbg_ptr, spo_arena_idx);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return BinaryRelationJs.__wrap(ret[0]);
}

/**
 * Validate that all `StrictPartialOrder` nodes in `model` have irreflexive
 * and transitive ordering relations.
 *
 * # Errors
 * Throws a JavaScript `Error` describing the first violation found.
 * @param {PowlModel} model
 */
export function validate_partial_orders(model) {
    _assertClass(model, PowlModel);
    const ret = wasm.validate_partial_orders(model.__wbg_ptr);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Validate a POWL model string against structural soundness criteria.
 *
 * Uses POWLJudge to check for deadlock freedom, liveness, and boundedness.
 * Returns a JSON object with `verdict` (boolean), `reasoning` (string),
 * and `violations` (array of violation strings).
 *
 * # Errors
 * Throws if the POWL string cannot be parsed.
 * @param {string} model_str
 * @returns {string}
 */
export function validate_powl_structure(model_str) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(model_str, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.validate_powl_structure(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Serialize an event log (JSON) to CSV format.
 *
 * Mirrors `pm4py.write_csv()`.
 * @param {string} log_json
 * @returns {string}
 */
export function write_csv_log(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.write_csv_log(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Serialize a DFG result to a canonical JSON string (round-trip safe).
 *
 * Takes the JSON output from `discover_dfg` and returns a pretty-printed JSON string.
 *
 * Mirrors `pm4py.write_dfg()`.
 * @param {string} dfg_json
 * @returns {string}
 */
export function write_dfg(dfg_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(dfg_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.write_dfg(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Serialize an event log (JSON) to XES XML format.
 *
 * Mirrors `pm4py.write_xes()`.
 * @param {string} log_json
 * @returns {string}
 */
export function write_xes_log(log_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(log_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.write_xes_log(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}
export function __wbg___wbindgen_is_function_49868bde5eb1e745(arg0) {
    const ret = typeof(arg0) === 'function';
    return ret;
}
export function __wbg___wbindgen_is_object_40c5a80572e8f9d3(arg0) {
    const val = arg0;
    const ret = typeof(val) === 'object' && val !== null;
    return ret;
}
export function __wbg___wbindgen_is_string_b29b5c5a8065ba1a(arg0) {
    const ret = typeof(arg0) === 'string';
    return ret;
}
export function __wbg___wbindgen_is_undefined_c0cca72b82b86f4d(arg0) {
    const ret = arg0 === undefined;
    return ret;
}
export function __wbg___wbindgen_throw_81fc77679af83bc6(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
}
export function __wbg_call_d578befcc3145dee() { return handleError(function (arg0, arg1, arg2) {
    const ret = arg0.call(arg1, arg2);
    return ret;
}, arguments); }
export function __wbg_crypto_38df2bab126b63dc(arg0) {
    const ret = arg0.crypto;
    return ret;
}
export function __wbg_getRandomValues_c44a50d8cfdaebeb() { return handleError(function (arg0, arg1) {
    arg0.getRandomValues(arg1);
}, arguments); }
export function __wbg_length_0c32cb8543c8e4c8(arg0) {
    const ret = arg0.length;
    return ret;
}
export function __wbg_msCrypto_bd5a034af96bcba6(arg0) {
    const ret = arg0.msCrypto;
    return ret;
}
export function __wbg_new_with_length_9cedd08484b73942(arg0) {
    const ret = new Uint8Array(arg0 >>> 0);
    return ret;
}
export function __wbg_node_84ea875411254db1(arg0) {
    const ret = arg0.node;
    return ret;
}
export function __wbg_process_44c7a14e11e9f69e(arg0) {
    const ret = arg0.process;
    return ret;
}
export function __wbg_prototypesetcall_3e05eb9545565046(arg0, arg1, arg2) {
    Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
}
export function __wbg_randomFillSync_6c25eac9869eb53c() { return handleError(function (arg0, arg1) {
    arg0.randomFillSync(arg1);
}, arguments); }
export function __wbg_require_b4edbdcf3e2a1ef0() { return handleError(function () {
    const ret = module.require;
    return ret;
}, arguments); }
export function __wbg_static_accessor_GLOBAL_THIS_a1248013d790bf5f() {
    const ret = typeof globalThis === 'undefined' ? null : globalThis;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
}
export function __wbg_static_accessor_GLOBAL_f2e0f995a21329ff() {
    const ret = typeof global === 'undefined' ? null : global;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
}
export function __wbg_static_accessor_SELF_24f78b6d23f286ea() {
    const ret = typeof self === 'undefined' ? null : self;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
}
export function __wbg_static_accessor_WINDOW_59fd959c540fe405() {
    const ret = typeof window === 'undefined' ? null : window;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
}
export function __wbg_subarray_0f98d3fb634508ad(arg0, arg1, arg2) {
    const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
    return ret;
}
export function __wbg_versions_276b2795b1c6a219(arg0) {
    const ret = arg0.versions;
    return ret;
}
export function __wbindgen_cast_0000000000000001(arg0, arg1) {
    // Cast intrinsic for `Ref(Slice(U8)) -> NamedExternref("Uint8Array")`.
    const ret = getArrayU8FromWasm0(arg0, arg1);
    return ret;
}
export function __wbindgen_cast_0000000000000002(arg0, arg1) {
    // Cast intrinsic for `Ref(String) -> Externref`.
    const ret = getStringFromWasm0(arg0, arg1);
    return ret;
}
export function __wbindgen_init_externref_table() {
    const table = wasm.__wbindgen_externrefs;
    const offset = table.grow(4);
    table.set(0, undefined);
    table.set(offset + 0, undefined);
    table.set(offset + 1, null);
    table.set(offset + 2, true);
    table.set(offset + 3, false);
}
const BinaryRelationJsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_binaryrelationjs_free(ptr >>> 0, 1));
const PowlModelFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_powlmodel_free(ptr >>> 0, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

function getArrayU32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let cachedUint32ArrayMemory0 = null;
function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
        cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;


let wasm;
export function __wbg_set_wasm(val) {
    wasm = val;
}
